import type { JSX } from "react";
import { useFadeInUp, useParallax, useFloating } from "../../../utils/animations";

export default function HeroSection(): JSX.Element {
  const headingRef = useFadeInUp(0.8, 0.2, 60);
  const subheadingRef = useFadeInUp(0.8, 0.4, 60);
  const descriptionRef = useFadeInUp(0.8, 0.6, 60);
  
  const leftCircleRef = useParallax(0.3);
  const rightCircleRef = useParallax(0.4);
  
  const leftCircleFloatRef = useFloating(4, 15);
  const rightCircleFloatRef = useFloating(3.5, 20);

  return (
    <section
      id="home"
      className="relative w-full h-screen flex items-center justify-center pt-24"
    >
      {/* Decorative Ellipses with Parallax and Floating */}
      <div 
        ref={(el) => {
          if (el) {
            leftCircleRef.current = el;
            leftCircleFloatRef.current = el;
          }
        }}
        className="absolute left-[-20vw] top-10 w-[40vw] max-w-[500px] aspect-square rounded-full bg-primary pointer-events-none z-0" 
      />
      <div 
        ref={(el) => {
          if (el) {
            rightCircleRef.current = el;
            rightCircleFloatRef.current = el;
          }
        }}
        className="absolute right-[-20vw] top-100 w-[40vw] max-w-[500px] aspect-square rounded-full bg-orange pointer-events-none z-0" 
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        <h1 
          ref={headingRef}
          className="font-urbanist font-bold text-primary text-h3 md:text-h2 lg:text-h1 tracking-tight mb-4 md:mb-6"
        >
          Coffee Code Community
        </h1>
        <h2 
          ref={subheadingRef}
          className="font-urbanist font-bold text-orange text-h4 md:text-h3 lg:text-h3 tracking-tight mb-6 md:mb-10 max-w-3xl"
        >
          Belajar teknologi dengan <br className="hidden sm:block" /> Santai,
          Konsisten, dan Berdaya Saing!
        </h2>
        <p 
          ref={descriptionRef}
          className="font-urbanist font-normal text-[#858585] text-h6 md:text-h5 lg:text-h4 tracking-tight max-w-4xl leading-relaxed"
        >
          Mulai perjalananmu di dunia teknologi bersama komunitas yang suportif. Di sini, kamu bisa belajar, berbagi, dan berkembang tanpa tekanan—karena konsistensi kecil hari ini adalah kunci kesuksesan besar di masa depan.
        </p>
      </div>
    </section>
  );
}